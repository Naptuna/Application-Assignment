package org.example.student.dotsboxgame

import uk.ac.bournemouth.ap.dotsandboxeslib.*
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.Matrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.MutableSparseMatrix
import uk.ac.bournemouth.ap.dotsandboxeslib.matrix.SparseMatrix
import kotlin.random.Random

class StudentDotsBoxGame(columns: Int = 8, rows: Int = 8, players: List<Player> = listOf(HumanPlayer(), HumanPlayer())) : AbstractDotsAndBoxesGame() {
    override val players: List<Player> = players.toList()  //TODO("You will need to get players from your constructor")

    override var currentPlayer: Player = players[0] //get()=TODO("Determine the current player, like keeping" +
                                                           //"the index into the players list")

    // NOTE: you may want to me more specific in the box type if you use that type in your class
    override val boxes: Matrix<StudentBox> = MutableMatrix(columns, rows, :: StudentBox)

    override val lines: SparseMatrix<DotsAndBoxesGame.Line>
            = MutableSparseMatrix(columns+1, rows*2+1, :: StudentLine,
                                  { x,y -> !(y%2 == 0 && x == columns)})

    override var isFinished: Boolean = false
        //get() = TODO("Provide this getter. Note you can make it a var to do so")

    override fun playComputerTurns() {
        var current = currentPlayer
        while (current is ComputerPlayer && ! isFinished) {
            current.makeMove(this)
            current = currentPlayer
        }
    }

    /**
     * This is an inner class as it needs to refer to the game to be able to look up the correct
     * lines and boxes. Alternatively you can have a game property that does the same thing without
     * it being an inner class.
     */
    inner class StudentLine(lineX: Int, lineY: Int) : AbstractLine(lineX, lineY) {
        override var isDrawn: Boolean = false
            //get() = TODO("Provide this getter. Note you can make it a var to do so")

        override val adjacentBoxes: Pair<StudentBox?, StudentBox?>
            get() {
                if (lineY%2 ==0 ){
                    if (lineY == 0) {
                        return Pair(null, boxes[lineX, lineY / 2])
                    }
                    if (lineY == lines.maxHeight-1) {
                        return Pair(boxes[lineX, (lineY - 2) / 2], null)
                    }
                    return Pair(boxes[lineX, (lineY-2)/2],boxes[lineX, lineY/2])
                }

                if (lineX == 0) {
                    return Pair(null, boxes[lineX, (lineY - 1) / 2])
                }
                if (lineX ==lines.maxWidth-1 ){
                    return Pair(boxes[lineX - 1, (lineY - 1) / 2], null)
                }
                return Pair(boxes[lineX - 1, (lineY - 1) / 2], boxes[lineX, (lineY - 1) / 2])
            }

        override fun drawLine() {

            var testPlayer = true

            if(isDrawn){
                throw Exception("Line has already been drawn")
            }

            this.isDrawn = true
            var remainingBoxes: Int = 0

            for (box in adjacentBoxes.toList()){
                if (box != null) {
                    if (box.boundingLines.filter{it.isDrawn}.count() == 4){
                        box.owningPlayer = currentPlayer
                        testPlayer = false
                    }
                }
            }

            for (box in boxes){
                if (box.owningPlayer == null){
                    remainingBoxes++
                }
            }

            val scores = getScores().mapIndexed{index, score -> Pair(players[index], score)}

            if (remainingBoxes == 0) {
                fireGameOver(scores)
                isFinished = true
            }

            if (testPlayer == true) {
                if (currentPlayer == players[1]) {
                    currentPlayer = players[0]
                } else {
                    currentPlayer = players[1]
                }
            }
            if (currentPlayer is ComputerPlayer){
                playComputerTurns()
            }
            fireGameChange()
            //TODO("Implement the logic for a player drawing a line. Don't forget to inform the listeners (fireGameChange, fireGameOver)")
            // NOTE read the documentation in the interface, you must also update the current player.
        }
    }

    inner class StudentBox(boxX: Int, boxY: Int) : AbstractBox(boxX, boxY) {

        override var owningPlayer: Player? = null
           // get() = TODO("Provide this getter. Note you can make it a var to do so")

        /**
         * This must be lazy or a getter, otherwise there is a chicken/egg problem with the boxes
         */
        override val boundingLines: Iterable<DotsAndBoxesGame.Line>

            get() = lines.filter { it.adjacentBoxes.first == this || it.adjacentBoxes.second == this}
        //TODO("Look up the correct lines from the game outer class")

    }
}