package uk.ac.bournemouth.ap.dotsandboxes

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import kotlinx.android.synthetic.main.activity_main.view.*
import org.example.student.dotsboxgame.StudentDotsBoxGame
import kotlin.math.floor

public class CustView: View {
    //Setting up the constructors
    constructor(context: Context?) :super(context)
    constructor(context: Context?, attrs: AttributeSet) : super(context, attrs)
    constructor(context: Context?, attrs: AttributeSet, defStyleAttr: Int):
            super(context, attrs, defStyleAttr)

    //Creating the basis for the gesture detection
    private val myGestureDetector = GestureDetector(context,myGesturelistener())

    //Deciding on the size of the grid
    private var gameLogic: StudentDotsBoxGame = StudentDotsBoxGame(5,5)
    private var columns = gameLogic.boxes.maxWidth
    private var rows = gameLogic.boxes.maxHeight

    //Used to store the score
    private var humanScore: Int = 0
    private var computerScore: Int = 0

    //used to colour in the assets e.g background, line colour
    private var dotPaint: Paint
    private var background: Paint
    private var textbackground: Paint
    private var linesPaint: Paint
    private var claimedLines: Paint
    private var unownedBoxes: Paint

    private var humanPlayer: Paint
    private var computerPlayer: Paint
    private var playerTitle: Paint

    //Changes the colour of the box when a specific player claims it
    private var humanOwned: Paint
    private var computerOwned: Paint

    // Text/Score Colors
    private var titleCol: Int = Color.BLACK
    private var humanCol: Int = Color.RED
    private var computerCol: Int = Color.BLUE

    //Paint application
    init{
        dotPaint = Paint().apply {
            setStrokeWidth(20f)
            setStrokeCap(Paint.Cap.SQUARE)
            setColor(Color.CYAN)
        }

        background = Paint().apply {
            style = Paint.Style.FILL
            setColor(Color.WHITE)
        }

        textbackground = Paint().apply {
            style = Paint.Style.FILL
            setColor(Color.WHITE)
        }


        linesPaint = Paint().apply {
            color = Color.GRAY
        }

        claimedLines = Paint().apply {
            color = Color.BLACK
        }

        unownedBoxes = Paint().apply {
            style = Paint.Style.FILL
            color = Color.DKGRAY
        }

        playerTitle = Paint().apply {
            setColor(titleCol)
            setTextAlign(Paint.Align.CENTER)
            setTextSize(70.toFloat())
            setTypeface(Typeface.SANS_SERIF)
        }

        humanPlayer = Paint().apply {
            setColor(humanCol)
            setTextAlign(Paint.Align.CENTER)
            setTextSize(70.toFloat())
            setTypeface(Typeface.SANS_SERIF)
        }

        humanOwned = Paint().apply {
            style = Paint.Style.FILL
            color = Color.RED
        }

        computerOwned = Paint().apply {
            style = Paint.Style.FILL
            color = Color.BLUE
        }

        computerPlayer = Paint().apply {
            setColor(computerCol)
            setTextAlign(Paint.Align.CENTER)
            setTextSize(70.toFloat())
            setTypeface(Typeface.SANS_SERIF)
        }
    }

    //Drawing the grid including boxes and lines
    override fun onDraw(canvas: Canvas) {
        //Getting the Height and Width
        val viewHeight: Float = height.toFloat()
        val viewWidth: Float = width.toFloat()

        //Displaying Score
        val score = gameLogic.getScores()

        humanScore = score[0]
        computerScore = score[1]

        canvas.drawRect(0.toFloat(), 0.toFloat(), viewWidth, viewHeight, background)

        val betweenDots: Float = (viewWidth - 20f*(columns+1))/columns

        for (boxes in gameLogic.boxes) {
            //Colouring in boxes after player 1 or Player 2 has claimed it
            var ownedboxes = unownedBoxes
            if (boxes.owningPlayer == gameLogic.players[0]) {
                ownedboxes = humanOwned
            } else if (boxes.owningPlayer == gameLogic.players[1]) {
                ownedboxes = computerOwned
            }

            // Planned Feature #1 (see README)
            //if (humanScore > computerScore)
            // {
            //canvas.drawText("Player 1 wins", 480f, 1350f, humanPlayer)
            // }
            //else if (humanScore < computerScore){
            //canvas.drawText("Player 2 wins", 480f, 1350f, computerPlayer)
            //}
           // else if (humanScore == computerScore){
                //canvas.drawText("It's a tie", 480f, 1350f, computerPlayer)
                //}

            //Draws the boxes onto the canvas
            canvas.drawRect(20 * (boxes.boxX+1) + betweenDots*boxes.boxX,
                            20 * (boxes.boxY+1) + betweenDots*boxes.boxY,
                            (20 * (boxes.boxX+1) + betweenDots*boxes.boxX)+betweenDots,
                            (20 * (boxes.boxY+1) + betweenDots*boxes.boxY)+betweenDots,
                            ownedboxes)
        }

        for (line in gameLogic.lines){
            var linepaint = linesPaint

            if (line.isDrawn == true){
                linepaint = claimedLines
            }

            //Draws the lines onto the canvas
            if (line.lineY%2 == 0){
                //Draws Horizontal Lines
                canvas.drawRect(20 *(line.lineX+1) + betweenDots * line.lineX,
                                line.lineY/2 * betweenDots + 20 * line.lineY/2,
                                (20 *(line.lineX +1) + betweenDots * (line.lineX))
                                        + betweenDots,
                                (line.lineY/2 * betweenDots + 20 * line.lineY/2)+20,
                                     linepaint)
            }

            else {
                //Draws Vertical Lines
                canvas.drawRect(20 *line.lineX + betweenDots*line.lineX,
                                20 * ((line.lineY+1)/2) + betweenDots* (((line.lineY+1)/2)-1),
                                (20 * line.lineX + betweenDots*line.lineX) +20,
                                (20*((line.lineY+1)/2) + betweenDots*(((line.lineY+1)/2)-1)) +
                                        betweenDots,
                                linepaint)
            }
        }

        //Draws the dots onto the canvas
        for (x in 0..rows) {
            for (y in 0..columns) {
                canvas.drawPoint((x * betweenDots + 20 * x) + 10,
                                 (y * betweenDots + 20 * y) + 10,
                                 dotPaint)
            }
        }

        //Draws the Scores and displays them

        canvas.drawText("Player list", 290f, 1250f, playerTitle)

        canvas.drawText("Player 1:", 280f, 1350f, humanPlayer)
        canvas.drawText(humanScore.toString(), 500f, 1350f, humanPlayer)

        canvas.drawText("Player 2:", 280f, 1450f, computerPlayer)
        canvas.drawText(computerScore.toString(), 500f, 1450f, computerPlayer)
    }



    //Gesture Controls
    override fun onTouchEvent(event: MotionEvent?): Boolean {
        return myGestureDetector.onTouchEvent(event) || super.onTouchEvent(event)
    }

    inner class myGesturelistener: GestureDetector.SimpleOnGestureListener(){
        override fun onDown(e: MotionEvent?): Boolean {
            return true
        }

        override fun onSingleTapUp(e: MotionEvent): Boolean {
            val colwidth = width/columns

            var detectionX = e.x
            var detectionY = e.y

            val detectboxX = floor( detectionX/colwidth)
            val detectboxY = floor (detectionY/colwidth)

            detectionX = detectionX - colwidth * detectboxX
            detectionY = detectionY - colwidth * detectboxY

            try {
                if (detectionX > detectionY) {
                    if (detectionX + detectionY > colwidth) {
                        gameLogic.lines[(detectboxX + 1).toInt(),
                                        (detectboxY * 2 + 1).toInt()].drawLine()
                    } else {
                        gameLogic.lines[detectboxX.toInt(),
                                       (detectboxY * 2).toInt()].drawLine()
                    }

                } else {
                    if (detectionX + detectionY > colwidth) {
                        gameLogic.lines[detectboxX.toInt(),
                                       ((detectboxY + 1) * 2).toInt()].drawLine()
                    } else {
                        gameLogic.lines[detectboxX.toInt(),
                                       (detectboxY * 2 + 1).toInt()].drawLine()
                    }
                }
            }
            catch (e:java.lang.Exception){
            }

            invalidate()

            return true
        }


    }
}