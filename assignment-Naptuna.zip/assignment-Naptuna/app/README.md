## Application Programming - Dots and Boxes Assessment Task

Student ID: s5114354
GitHub Repository: https://github.com/Naptuna/Application-Assignment.git

--Features--
- Displays Player 1 & 2 Scores
- Claimed boxes switches colour from grey to red/blue depending on who claimed it
- Lines switch to black when claimed and cannot be selected again
- Currently only supports 2 Human players (didn't have enough time to add a computerbot)

--Planned Features--
- It was planned to have a winning message appear where a player ended up with the highest score 
  by the end of the game 
- I also planned on having a countdown feature where the players must complete the boxes in a
  limited amount of time 
 
 --Extensions-- 
 - None
